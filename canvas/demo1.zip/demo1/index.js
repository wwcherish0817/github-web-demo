/**
 * Created by game on 2016/10/27.
 */

var mycanvas = document.getElementById("mycanvas")  ;
var ctx = mycanvas.getContext('2d');

//̫��
ctx.beginPath();
ctx.fillStyle = "rgb(255, 115,22)";
ctx.arc(609,124,98,0, Math.PI*2,false);
//ctx.closePath();
ctx.fill();

//̫�����۾�
ctx.beginPath();
ctx.fillStyle = "rgb(255, 255,255)";
ctx.arc(572,126,13,0, Math.PI*2,false);
ctx.closePath();
ctx.fill();

ctx.beginPath();
ctx.strokeStyle = "rgb(255, 255,255)";
ctx.lineWidth = 2;
ctx.arc(572,126,20,0, Math.PI*2,false);
ctx.closePath();
ctx.stroke();


ctx.beginPath();
ctx.fillStyle = "rgb(255, 255,255)";
ctx.arc(642,106,13,0, Math.PI*2,false);
ctx.closePath();
ctx.fill();

ctx.beginPath();
ctx.strokeStyle = "rgb(255, 255,255)";
ctx.lineWidth = 2;
ctx.arc(642,106,20,0, Math.PI*2,false);
ctx.closePath();
ctx.stroke();

//̫����
ctx.beginPath();
ctx.strokeStyle = "rgb(255, 255,255)";
ctx.moveTo(603, 177);
ctx.lineTo(641, 161);
ctx.stroke();

//�̱���1  --ɽ1
ctx.beginPath();
ctx.fillStyle = "rgb(66, 88,5)";
ctx.moveTo(0, 380);
ctx.lineTo(329, 198);
ctx.lineTo(733, 374);
ctx.lineTo(1000, 250);
ctx.lineTo(1000, 708);
ctx.lineTo(0, 708);
ctx.lineTo(0, 380);
ctx.closePath();
ctx.fill();

//�̱���2    --ɽ2
ctx.beginPath();
ctx.fillStyle = "rgb(96, 122,27)";
ctx.moveTo(462, 708);
ctx.lineTo(913, 58);
ctx.lineTo(1000, 237);
ctx.lineTo(1000, 708);
ctx.lineTo(462, 708);
ctx.closePath();
ctx.fill();

//����ǽ
ctx.beginPath();
ctx.fillStyle = "rgb(255, 137,137)";
ctx.moveTo(114, 708);
ctx.lineTo(114, 515);
ctx.lineTo(375, 515);
ctx.lineTo(375, 708);
ctx.closePath();
ctx.fill();

//���Ӵ���
ctx.beginPath();
ctx.fillStyle = "rgb(255, 255,255)";
ctx.moveTo(191, 638);
ctx.lineTo(191, 531);
ctx.lineTo(298, 531);
ctx.lineTo(298, 638);
ctx.closePath();
ctx.fill();

//����
ctx.beginPath();
ctx.fillStyle = "rgb(245, 36,36)";
ctx.moveTo(51, 515);
ctx.lineTo(245, 180);
ctx.lineTo(438, 515);
ctx.closePath();
ctx.fill();

//��·
ctx.beginPath();
ctx.fillStyle = "rgb(142, 142,142)";
ctx.moveTo(0, 708);
ctx.lineTo(1000, 708);
ctx.lineTo(1000, 870);
ctx.lineTo(0, 870);
ctx.closePath();
ctx.fill();

//·�߲ݴ�
ctx.beginPath();
ctx.fillStyle = "rgb(7, 116,22)";
ctx.moveTo(0, 870);
ctx.lineTo(1000, 870);
ctx.lineTo(1000, 1000);
ctx.lineTo(0, 1000);
ctx.closePath();
ctx.fill();

//դ��  ����
var initX = 486,initY1=787,initY2=881;
for(var i=1;i<=5;i++){
    ctx.beginPath();
    ctx.fillStyle = "rgb(229, 172,20)";
    ctx.moveTo(initX, initY1);
    ctx.lineTo(initX+27, initY1);
    ctx.lineTo(initX+27, initY2);
    ctx.lineTo(initX, initY2);
    ctx.closePath();
    ctx.fill();
    initX+=53;
}

//դ�� ����
ctx.beginPath();
ctx.fillStyle = "rgb(229, 172,20)";
ctx.moveTo(460, 821);
ctx.lineTo(initX, 821);
ctx.lineTo(initX, 848);
ctx.lineTo(460, 848);
ctx.closePath();
ctx.fill();




